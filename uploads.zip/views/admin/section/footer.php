</div>
</div>
</div>
</div>
</div>

<div id="styleSelector">
</div>

</div>
</div>
</div>
</div>


<!--[if lt IE 10]>
    <div class="ie-warning">
        <h1>Warning!!</h1>
        <p>You are using an outdated version of Internet Explorer, please upgrade
            <br/>to any of the following web browsers to access this website.
        </p>
        <div class="iew-container">
            <ul class="iew-download">
                <li>
                    <a href="http://www.google.com/chrome/">
                        <img src="../files/assets/images/browser/chrome.png" alt="Chrome">
                        <div>Chrome</div>
                    </a>
                </li>
                <li>
                    <a href="https://www.mozilla.org/en-US/firefox/new/">
                        <img src="../files/assets/images/browser/firefox.png" alt="Firefox">
                        <div>Firefox</div>
                    </a>
                </li>
                <li>
                    <a href="http://www.opera.com">
                        <img src="../files/assets/images/browser/opera.png" alt="Opera">
                        <div>Opera</div>
                    </a>
                </li>
                <li>
                    <a href="https://www.apple.com/safari/">
                        <img src="../files/assets/images/browser/safari.png" alt="Safari">
                        <div>Safari</div>
                    </a>
                </li>
                <li>
                    <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                        <img src="../files/assets/images/browser/ie.png" alt="">
                        <div>IE (9 & above)</div>
                    </a>
                </li>
            </ul>
        </div>
        <p>Sorry for the inconvenience!</p>
    </div>
<![endif]-->


<script type="2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/jquery.min.js"></script>
<script type="2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/jquery-ui.min.js"></script>
<script type="2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/popper.min.js"></script>
<script type="2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/bootstrap.min.js"></script>

<script src="<?=$urls?>views/admin/assets/js/waves.min.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>

<script type="2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/jquery.slimscroll.js"></script>

<script src="<?=$urls?>views/admin/assets/js/jquery.flot.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script src="<?=$urls?>views/admin/assets/js/jquery.flot.categories.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script src="<?=$urls?>views/admin/assets/js/curvedlines.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script src="<?=$urls?>views/admin/assets/js/jquery.flot.tooltip.min.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>

<script src="<?=$urls?>views/admin/assets/js/amcharts.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script src="<?=$urls?>views/admin/assets/js/serial.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script src="<?=$urls?>views/admin/assets/js/light.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script src="<?=$urls?>views/admin/assets/js/sweetalert.min.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>

<script src="<?=$urls?>views/admin/assets/js/markerclusterer.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script type="<?=$urls?>views/admin/assets/2d8d78e876b340f9029c575b-text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script>
<script type="<?=$urls?>views/admin/assets/2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/gmaps.js"></script>

<script type="88add89075ed2b878b934720-text/javascript" src="<?=$urls?>views/admin/assets/js/select2.full.min.js"></script>

<script type="88add89075ed2b878b934720-text/javascript" src="<?=$urls?>views/admin/assets/js/bootstrap-multiselect.js">
</script>
<script type="88add89075ed2b878b934720-text/javascript" src="<?=$urls?>views/admin/assets/js/jquery.multi-select.js"></script>
<script type="88add89075ed2b878b934720-text/javascript" src="<?=$urls?>views/admin/assets/js/jquery.quicksearch.js"></script>
<script type="88add89075ed2b878b934720-text/javascript" src="<?=$urls?>views/admin/assets/js/select2-custom.js"></script>
<script src="<?=$urls?>views/admin/assets/js/pcoded.min.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script src="<?=$urls?>views/admin/assets/js/vertical-layout.min.js" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script type="2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/crm-dashboard.min.js"></script>
<script type="2d8d78e876b340f9029c575b-text/javascript" src="<?=$urls?>views/admin/assets/js/script.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gmaps.js/0.4.25/gmaps.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script>
  $(document).ready(function () {
    let currentPath = window.location.pathname;

    $('.pcoded-submenu li a').each(function () {
      let $this = $(this);
      let linkPath = $this.attr('href');

      // Match the current path
      if (linkPath === currentPath) {
        $this.closest('li').addClass('active'); // Activate submenu item
        $this.closest('.pcoded-hasmenu').addClass('active pcoded-trigger'); // Open parent menu
      }
    });
  });
</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="2d8d78e876b340f9029c575b-text/javascript"></script>
<script type="2d8d78e876b340f9029c575b-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script src="<?=$urls?>views/admin/assets/js/rocket-loader.min.js" data-cf-settings="2d8d78e876b340f9029c575b-|49" defer=""></script></body>
<?php flash_message() ?>
<!-- Mirrored from colorlib.com/polygon/admindek/default/dashboard-crm.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Dec 2019 16:08:32 GMT -->
</html>
