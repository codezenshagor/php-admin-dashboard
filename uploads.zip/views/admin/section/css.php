<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="<?=$urls?>views/admin/assets/css/bootstrap.min.css">

<link rel="stylesheet" href="<?=$urls?>views/admin/assets/css/waves.min.css" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="<?=$urls?>views/admin/assets/css/feather.css?<?=time()?>">

<link rel="stylesheet" type="text/css" href="<?=$urls?>views/admin/assets/css/font-awesome-n.min.css">

<link rel="stylesheet" href="<?=$urls?>views/admin/assets/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" href="<?=$urls?>views/admin/assets/css/sweetalert.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="<?=$urls?>views/admin/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="<?=$urls?>views/admin/assets/css/widget.css">
<link rel="stylesheet" href="<?=$urls?>views/admin/assets/css/select2.min.css" />
<link rel="stylesheet" type="text/css" href="<?=$urls?>views/admin/assets/css/bootstrap-multiselect.css" />
<link rel="stylesheet" type="text/css" href="<?=$urls?>views/admin/assets/css/multi-select.css" />
<!-- Toastr CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />

<!-- jQuery (required by toastr) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Toastr JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>