<?php
 if($request[0]=='admin' AND $request[1]=='shop-user'AND TOTAL==2){
    require_once("views/admin/shop-user/shop-user.php");
    die();
 }